#include "calibration.h"
#include "iostream"

using namespace std;
using namespace cv;
#pragma warning(once : 4996) //_CRT_SECURE_NO_WARNINGS	ȥ��localtime��sprinft����ȫ����

static void help()
{
	printf("This is a camera calibration sample.\n");
}

int main(int argc, char** argv)
{
	cout << argc << endl;
	for (size_t i = 0; i < argc; i++)
	{
		cout << argv[i] << endl;
	}

	Size boardSize, imageSize;
	float squareSize, aspectRatio;
	Mat cameraMatrix, distCoeffs;
	string outputFilename;
	string inputFilename = "";

	bool writeExtrinsics, writePoints;	//writeExtrinsics Ϊfalse��д�����б궨ͼ��ת�����ƽ�ƾ��󣬷�����д��
	int i, nframes;
	bool undistortImage = false;
	int flags = 0;
	VideoCapture capture;
	bool flipVertical;
	bool showUndistorted;
	bool videofile;
	int delay;
	clock_t prevTimestamp = 0;
	int mode = DETECTION; // DETECTION = 0, CAPTURING = 1, CALIBRATED = 2 
	int cameraId = 0;
	vector<vector<Point2f> > imagePoints;	//ͼƬ��ά�����x,y
	vector<string> imageList;	//�궨ͼƬ
	Pattern pattern = CIRCLES_GRID;	//�궨ͼ�����ͣ��Գ�Բ��ͼ��

	cv::CommandLineParser parser(argc, argv,
		"{help ||}{w|7|}{h|7|}{pt|circles|}{n|16|}{d|10|}{s|0.03|}{o|F:\\Graduationproject\\Code\\calibration\\\out_camera_data.yml|}"
		"{op|F:\\Graduationproject\\Code\\calibration\\Detected_feature_points.yml|}{oe|F:\\Graduationproject\\Code\\calibration\\Detected_feature_points.yml|}{zt||}{a|1|}{p||}{v||}{V||}{su||}"
		"{input_data|F:\\Graduationproject\\Code\\calibration\\VID7x7_CircleGrid.xml|}");
	//�����в�����ֵ������˵����w,hΪ�궨�������; ptΪ�궨ͼ������; nΪ��ȡͼƬ������; dΪ�������ץͼ��ʱ����
	//oΪ�������������ڲΡ�����ļ�(�Զ�����ļ�);
	//aΪ���߱���ϵ����Ĭ��Ϊ1;input_dataΪ���ͼƬ·����xml�ļ�
	if (parser.has("help"))
	{
		help();
		return 0;
	}
	boardSize.width = parser.get<int>("w");
	boardSize.height = parser.get<int>("h");
	if (parser.has("pt"))
	{
		string val = parser.get<string>("pt");
		if (val == "circles")
			pattern = CIRCLES_GRID;
		else if (val == "acircles")
			pattern = ASYMMETRIC_CIRCLES_GRID;
		else if (val == "chessboard")
			pattern = CHESSBOARD;
		else
			return fprintf(stderr, "Invalid pattern type: must be chessboard or circles\n"), -1;
	}
	squareSize = parser.get<float>("s");
	nframes = parser.get<int>("n");
	aspectRatio = parser.get<float>("a");
	delay = parser.get<int>("d");
	writePoints = parser.has("op");
	writeExtrinsics = parser.has("oe");
	if (parser.has("a"))
		flags |= CALIB_FIX_ASPECT_RATIO;
	if (parser.has("zt"))
		flags |= CALIB_ZERO_TANGENT_DIST;
	if (parser.has("p"))
		flags |= CALIB_FIX_PRINCIPAL_POINT;
	flipVertical = parser.has("v");
	videofile = parser.has("V");
	if (parser.has("o"))
		outputFilename = parser.get<string>("o");
	showUndistorted = parser.has("su");
	if (isdigit(parser.get<string>("input_data")[0]))
		cameraId = parser.get<int>("input_data");
	else
		inputFilename = parser.get<string>("input_data");

	if (!parser.check())
	{
		help();
		parser.printErrors();
		return -1;
	}
	if (squareSize <= 0)
		return fprintf(stderr, "Invalid board square width\n"), -1;
	if (nframes <= 3)
		return printf("Invalid number of images\n"), -1;
	if (aspectRatio <= 0)
		return printf("Invalid aspect ratio\n"), -1;
	if (delay <= 0)
		return printf("Invalid delay\n"), -1;
	if (boardSize.width <= 0)
		return fprintf(stderr, "Invalid board width\n"), -1;
	if (boardSize.height <= 0)
		return fprintf(stderr, "Invalid board height\n"), -1;

	if (!inputFilename.empty())
	{
		if (!videofile && readStringList(inputFilename, imageList))
			mode = CAPTURING;	//�޸�modeΪץȡͼƬ
		else
			capture.open(inputFilename);
	}
	else
		capture.open(cameraId);

	if (!capture.isOpened() && imageList.empty())
		return fprintf(stderr, "Could not initialize video (%d) capture\n", cameraId), -2;

	if (!imageList.empty())
		nframes = (int)imageList.size();

	namedWindow("Image View", WINDOW_NORMAL);

	for (i = 0;; i++)
	{
		Mat view, viewGray;
		bool blink = false;
		//cout << i << endl;
		if (capture.isOpened())
		{
			Mat view0;
			capture >> view0;
			view0.copyTo(view);
		}
		else if (i < (int)imageList.size())
			view = imread(imageList[i], 1);

		if (view.empty())	//����ͼƬ�궨�����󣬿�ʼ��������������
		{
			if (imagePoints.size() > 0)
				runAndSave(outputFilename, imagePoints, imageSize,
					boardSize, pattern, squareSize, aspectRatio,
					flags, cameraMatrix, distCoeffs,
					writeExtrinsics, writePoints);
			break;
		}

		imageSize = view.size();

		if (flipVertical)
			flip(view, view, 0);

		vector<Point2f> pointbuf;
		cvtColor(view, viewGray, COLOR_BGR2GRAY);

		bool found;
		switch (pattern)
		{
		case CHESSBOARD:
			found = findChessboardCorners(view, boardSize, pointbuf,
				CALIB_CB_ADAPTIVE_THRESH | CALIB_CB_FAST_CHECK | CALIB_CB_NORMALIZE_IMAGE);
			break;
		case CIRCLES_GRID:
			found = findCirclesGrid(view, boardSize, pointbuf, CALIB_CB_SYMMETRIC_GRID);
			break;
		case ASYMMETRIC_CIRCLES_GRID:
			found = findCirclesGrid(view, boardSize, pointbuf, CALIB_CB_ASYMMETRIC_GRID);
			break;
		default:
			return fprintf(stderr, "Unknown pattern type\n"), -1;
		}

		// improve the found corners' coordinate accuracy
		if (pattern == CHESSBOARD && found) cornerSubPix(viewGray, pointbuf, Size(11, 11),
			Size(-1, -1), TermCriteria(TermCriteria::EPS + TermCriteria::COUNT, 30, 0.1));

		if (mode == CAPTURING && found &&
			(!capture.isOpened() || clock() - prevTimestamp > delay * 1e-3 * CLOCKS_PER_SEC))
		{
			imagePoints.push_back(pointbuf);	//��ȡͼ�������x,y
			prevTimestamp = clock();
			blink = capture.isOpened();
		}

		if (found)
			drawChessboardCorners(view, boardSize, Mat(pointbuf), found);	//����Բ�ĵ�

		string msg = mode == CAPTURING ? "100/100" :
			mode == CALIBRATED ? "Calibrated" : "Press 'g' to start";
		int baseLine = 0;
		Size textSize = getTextSize(msg, 1, 1, 1, &baseLine);
		Point textOrigin(view.cols - 2 * textSize.width - 10, view.rows - 2 * baseLine - 10);

		if (mode == CAPTURING)
		{
			if (undistortImage)
				msg = format("%d/%d Undist", (int)imagePoints.size(), nframes);	//д�쳣��Ϣ
			else
				msg = format("%d/%d", (int)imagePoints.size(), nframes);
		}

		putText(view, msg, textOrigin, 1, 1,
			mode != CALIBRATED ? Scalar(0, 0, 255) : Scalar(0, 255, 0));

		if (blink)
			bitwise_not(view, view);

		if (mode == CALIBRATED && undistortImage)
		{
			Mat temp = view.clone();
			undistort(temp, view, cameraMatrix, distCoeffs);
		}

		imshow("Image View", view);
		char key = (char)waitKey(capture.isOpened() ? 50 : 500);

		if (key == 27)
			break;

		if (key == 'u' && mode == CALIBRATED)
			undistortImage = !undistortImage;

		if (capture.isOpened() && key == 'g')
		{
			mode = CAPTURING;
			imagePoints.clear();
		}

		if (mode == CAPTURING && imagePoints.size() >= (unsigned)nframes)
		{
			if (runAndSave(outputFilename, imagePoints, imageSize,
				boardSize, pattern, squareSize, aspectRatio,
				flags, cameraMatrix, distCoeffs,
				writeExtrinsics, writePoints))
				mode = CALIBRATED;
			else
				mode = DETECTION;
			if (!capture.isOpened())
				break;
		}
	}

	if (!capture.isOpened() && showUndistorted)
	{
		Mat view, rview, map1, map2;
		initUndistortRectifyMap(cameraMatrix, distCoeffs, Mat(),
			getOptimalNewCameraMatrix(cameraMatrix, distCoeffs, imageSize, 1, imageSize, 0),
			imageSize, CV_16SC2, map1, map2);

		for (i = 0; i < (int)imageList.size(); i++)
		{
			view = imread(imageList[i], 1);
			if (view.empty())
				continue;
			//undistort( view, rview, cameraMatrix, distCoeffs, cameraMatrix );
			remap(view, rview, map1, map2, INTER_LINEAR);
			imshow("Image View", rview);
			char c = (char)waitKey();
			if (c == 27 || c == 'q' || c == 'Q')
				break;
		}
	}
	std::cout << "-------------����ڲ�-------------" << endl;
	cout<<cv::format(cameraMatrix,cv::Formatter::FMT_MATLAB)<<endl;
	std::cout << "-------------�������-------------" << endl;
	cout << cv::format(distCoeffs, cv::Formatter::FMT_MATLAB) << endl;

	vector<double> vecR;
	Vec3d TT;
	Matx33d RR;
	vector<Point3f> objectPoints_out{ {-92.1248,-33.5201,758.898},//��1
								  {-48.9144,-30.6222,659.422},//��7
								  {65.5723,-31.9757,786.758},//��9
								  {-209.113,-34.4865,754.296}, };//��4
	vector<Point2f> imagePoints_out{ {239,228},
								 {271,241},
								 {430,235},
								 {109,222}, };
	vector<Point3f> checkpoint3D{ 
	{183.471,-77.1759,834.758},
 {-35.4659,-77.7449,703.686},
 {-52.8291,-77.6554,543.886},
 {116.998,-77.4321,963.956},
 {63.73,-141.895,947.532},
 {87.9314,-141.515,637.009},//��1
 };//��9};
	vector<Point2f> checkpoint2D{ {222,166},};
	vector<Point2f> out_image;
	double err=0;
	cv::solvePnP(objectPoints_out, imagePoints_out, cameraMatrix, distCoeffs, vecR, TT);
	cv::Rodrigues(vecR, RR);
	cv::projectPoints(objectPoints_out, vecR, TT, cameraMatrix, distCoeffs, out_image);
	std::cout << "--------------��ά��-------------" << std::endl;
	//for (size_t i = 0; i < out_image.size(); i++)
	//{
	//	std::cout << "u=" << out_image[i].x << "v=" << out_image[i].y <<"/n" << std::endl;
	//}
	err = norm(imagePoints_out, out_image, NORM_L2);
	std::cout << "------------��ת����-------------" << endl;
	std::cout << RR << endl;
	std::cout << "------------ƽ�ƾ���-------------" << endl;
	std::cout << TT << endl;
	std::cout << "------------���-------------" << endl;
	std::cout << err << endl;
	return 0;
}